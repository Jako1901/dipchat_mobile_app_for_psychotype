package com.example.dipchat

data class User(
    val name: String? = null,
    val message: String? = null,
    val type: String? = null
)
