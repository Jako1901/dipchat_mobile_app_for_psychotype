package com.example.dipchat

data class Profile(
    val message: String? = null,
    val name: String? = null,
    val type: String? = null
)